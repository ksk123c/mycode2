import { Card } from "@/components/ui/card";
import { Award, Target, Users } from "lucide-react";
import femaleLeader from "@assets/generated_images/Female_technology_executive_headshot_34aff063.png";
import maleLeader from "@assets/generated_images/Male_technology_leader_headshot_ac13aa98.png";

const leaders = [
  {
    name: "Dr. Sarah Chen",
    title: "Chief Technology Officer",
    image: femaleLeader,
    bio: "15+ years in AI research and enterprise solutions, PhD in Machine Learning from MIT",
  },
  {
    name: "Michael Rodriguez",
    title: "VP of Cloud Engineering",
    image: maleLeader,
    bio: "Former AWS Solutions Architect, specialized in large-scale cloud infrastructure",
  },
];

export function About() {
  return (
    <section id="about" className="py-24 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            About <span className="text-primary">TechVision</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Leading the future of enterprise technology through innovation, expertise, and proven results
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-12 mb-20">
          <div className="lg:col-span-1 space-y-6">
            <Card className="p-8 hover-elevate transition-all duration-300 border-card-border">
              <Award className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-semibold mb-3">Industry Leaders</h3>
              <p className="text-muted-foreground leading-relaxed">
                Recognized globally for excellence in AI implementation, cloud architecture, 
                and digital transformation consulting.
              </p>
            </Card>

            <Card className="p-8 hover-elevate transition-all duration-300 border-card-border">
              <Target className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-semibold mb-3">Mission Driven</h3>
              <p className="text-muted-foreground leading-relaxed">
                Empowering businesses to harness the full potential of emerging technologies 
                for sustainable competitive advantage.
              </p>
            </Card>

            <Card className="p-8 hover-elevate transition-all duration-300 border-card-border">
              <Users className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-semibold mb-3">Expert Team</h3>
              <p className="text-muted-foreground leading-relaxed">
                200+ certified professionals across AI, cloud, development, and strategic consulting 
                domains worldwide.
              </p>
            </Card>
          </div>

          <div className="lg:col-span-2 space-y-8">
            <div className="prose prose-lg max-w-none">
              <h3 className="text-2xl font-semibold text-foreground mb-4">
                Transforming Enterprise Technology Since 2009
              </h3>
              <p className="text-muted-foreground leading-relaxed mb-6">
                TechVision Solutions stands at the forefront of enterprise technology transformation. 
                We specialize in AI-powered solutions, cloud infrastructure, and comprehensive digital 
                transformation strategies that deliver measurable ROI.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Our expertise spans machine learning, data analytics, web and mobile development, 
                cloud architecture, UI/UX design, and emerging technologies like AR/VR and IoT. 
                We've partnered with Fortune 500 companies and innovative startups alike to build 
                scalable, future-proof solutions.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                With a commitment to excellence and a track record of over 500 successful projects, 
                we're your trusted partner in navigating the complex landscape of modern technology.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mt-12">
              {leaders.map((leader) => (
                <Card
                  key={leader.name}
                  className="p-6 hover-elevate transition-all duration-300 border-card-border"
                >
                  <div className="flex items-start gap-4">
                    <img
                      src={leader.image}
                      alt={leader.name}
                      className="w-20 h-20 rounded-full object-cover border-2 border-primary/20"
                      data-testid={`img-leader-${leader.name.toLowerCase().replace(/\s+/g, '-')}`}
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold text-lg text-foreground">
                        {leader.name}
                      </h4>
                      <p className="text-sm text-primary font-medium mb-2">
                        {leader.title}
                      </p>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {leader.bio}
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
